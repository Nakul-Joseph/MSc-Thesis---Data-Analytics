# libraries used.
#========================================================

library("aimsir17")
library(tidyverse)
library(readxl)
library(lubridate)

# weather observation and station data (aimsir17).
#========================================================

obs <- aimsir17::observations
stn <- aimsir17::stations

#write.csv(obs,"observations.csv")
#write.csv(stn,"stations.csv")

# power generation data from Eirgrid.
#=======================================================

power_data <- read_xlsx("../data/IrelandData January 2017.xlsx")

# select date and wind power data.
#=======================================================

wind_data <- power_data %>% select(DateTime,Wind)

# add new columns year, month,day, hour and average it.
#=======================================================

wind_data %>% mutate(year = year(DateTime),
                     day = day(DateTime), 
                     month = month(DateTime), 
                     hour = hour(DateTime)) -> wind_data

wind_data %>% group_by(year, month,day,hour) %>% 
              summarise(avg_wind_pwr = mean(Wind)) -> wind_power_average

head(wind_power_average)

# Filter weather data in range 29-Jan to 26 Feb.
#=======================================================

filtered_weather_data <- obs[obs$date >= as.Date("2017-01-29"),]
filtered_weather_data <- obs[obs$date < as.Date("2017-02-27"),]

Jan29_to_Feb26 <- inner_join(filtered_weather_data,
                             wind_power_average,
                             by = c("year","month","day","hour"))

# 17400 to 16006.
Jan29_to_Feb26 <- Jan29_to_Feb26[complete.cases(Jan29_to_Feb26),]

write.csv(Jan29_to_Feb26,"../data/Jan29_to_Feb26.csv")
# filter weather data based on weather station.
# ======================================================

# ATHENRY

ath_data <- filtered_weather_data %>% filter(station == "ATHENRY")
athenry <- inner_join(ath_data,wind_power_average,by = c("year","month","day","hour"))
write.csv(athenry,"athenry.csv")

# BALLYHAISE
ballyhaise_data <- filtered_weather_data %>% filter(station == "BALLYHAISE")
ballyhaise <- inner_join(ballyhaise_data,wind_power_average,by = c("year","month","day","hour"))
write.csv(ballyhaise,"ballyhaise.csv")

# BELMULLET
belmullet_data <- filtered_weather_data %>% filter(station == "BELMULLET")
belmullet <- inner_join(belmullet_data,wind_power_average,by = c("year","month","day","hour"))
write.csv(belmullet,"belmullet.csv")

# Plot
#=======================================================

plot_data = read.csv("../data/AllAlgo_for_all_counties.csv")

# All algo plot for all stations.
ggplot(data = plot_data,mapping = aes(x = Station,y=RMSE, colour=Algorithm)) +
  #geom_col(position = "dodge") +
  geom_point()+
theme_classic() +
  ggtitle("RMSE scores of weather stations") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )

# AdaBoost plot
plot_data %>% filter(Algorithm=='AdaBoost')->d1
d1<-d1[order(d1$RMSE),]
ggplot(d1, aes(x=reorder(Station,RMSE),y=RMSE, group='Algorithm')) +
  geom_line() +  geom_point() +
  scale_y_continuous(breaks = seq(300,500,by=10)) +
  theme_classic() +
  ggtitle("RMSE scores for AdaBoost") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )

# KNN plot
plot_data %>% filter(Algorithm=='KNN')->d2
d2<-d2[order(d2$RMSE),]
ggplot(d2, aes(x=reorder(Station,RMSE),y=RMSE, group='Algorithm')) +
  geom_line() +  geom_point() +
  scale_y_continuous(breaks = seq(300,500,by=10)) +
  theme_classic() +
  ggtitle("RMSE scores for KNN") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )

# joining with stations data.
plot_data$station <- plot_data$Station
pd <- inner_join(plot_data,stations,by="station")
pd$station <- NULL

ada_pd <- filter(pd,Algorithm=='AdaBoost')
ggplot(data = ada_pd,aes(x=reorder(county,RMSE), y=RMSE)) +
  geom_point() +
  scale_y_continuous(breaks = seq(300,500,by=10)) +
theme_classic() +
  ggtitle("RMSE scores based on counties") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )
# ==============================================

# Power vs Wind speed.

Jan29_to_Feb26 %>% group_by(wdsp)%>% summarise(mean_pwr = mean(avg_wind_pwr)) -> pwr_vs_wdsp

ggplot(data=pwr_vs_wdsp, aes(x=pwr_vs_wdsp$wdsp,y=pwr_vs_wdsp$mean_pwr)) +
  geom_point() + geom_smooth() +
  scale_y_continuous(breaks = seq(0,4000,by=500)) +
  theme_classic() +
  ggtitle("Wind Power vs. Wind Speed") +
  labs(x = "Wind Speed", y="Wind Power") +
  theme(
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
  )
# Power vs msl.

Jan29_to_Feb26 %>% group_by(msl)%>% summarise(mean_pwr = mean(avg_wind_pwr)) -> pwr_vs_msl

ggplot(data=pwr_vs_msl, aes(x=pwr_vs_msl$msl,y=pwr_vs_msl$mean_pwr)) +
  geom_point() + geom_smooth() +
  scale_y_continuous(breaks = seq(0,4000,by=500)) +
  theme_classic() +
  ggtitle("Wind Power vs. MSL") +
  labs(x = "MSL", y="Wind Power") +
  theme(
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
  )

#=================================================
# Power vs Wind direction

Jan29_to_Feb26 %>% group_by(wddir)%>% summarise(mean_pwr = mean(avg_wind_pwr)) -> pwr_vs_wddir

ggplot(data=pwr_vs_wddir, aes(x=pwr_vs_wddir$wddir,y=pwr_vs_wddir$mean_pwr)) +
  geom_point() + geom_smooth() +
  scale_y_continuous(breaks = seq(0,4000,by=500)) +
  theme_classic() +
  ggtitle("Wind Power vs. Wind Direcction") +
  labs(x = "Wind Direction", y="Wind Power") +
  theme(
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
  )

#================================================
# Plots based on Adjusted Rsquared.

r2_data = read.csv("../data/AllAlgo_for_all_counties_with_R2.csv")

# All algo plot for all stations.
ggplot(data = r2_data,mapping = aes(x = Station,y=Adjusted_R2, colour=Algorithm, shape=Algorithm)) +
  #geom_col(position = "dodge") +
  geom_point()+
  theme_classic() +
  ggtitle("Adjusted R2 scores of weather stations") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )

#==================================
# AdaBoost plot with adjucted r2
r2_data %>% filter(Algorithm=='AdaBoost')->r2_ada

r2_ada<-r2_ada[order(r2_ada$Adjusted_R2),]
ggplot(r2_ada, aes(x=reorder(Station,Adjusted_R2),y=Adjusted_R2, group='Algorithm')) +
  geom_point() +
  scale_y_continuous(breaks = seq(0.50,1,by=0.05)) +
  theme_classic() +
  ggtitle("Adjusted R2 scores for AdaBoost") +
  ylab("Adjusted R squared") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )

# =============================================
# plot with adjusted r2 scores per county.

r2_data$station <- r2_data$Station
pd_r2 <- inner_join(r2_data,stations,by="station")
pd_r2$station <- NULL

ada_pd_r2 <- filter(pd_r2,Algorithm=='AdaBoost')
ggplot(data = ada_pd_r2,aes(x=reorder(county,-Adjusted_R2), y=Adjusted_R2)) +
  geom_point() +
  scale_y_continuous(breaks = seq(0.50,1,by=0.05)) +
  theme_classic() +
  ggtitle("Adjusted R2 scores based on counties") +
  ylab("Adjusted R squared") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )
#==========================================================
# plot with adjusted r2 scores per county.

r2_data$station <- r2_data$Station
pd_r2 <- inner_join(r2_data,stations,by="station")
pd_r2$station <- NULL

ada_pd_r2 <- filter(pd_r2,Algorithm=='AdaBoost')

ada_pd_r2 %>% group_by(county) %>% summarise(avg_r2=mean(Adjusted_R2)) -> ada_pd_r2

ggplot(data = ada_pd_r2,aes(x=reorder(county,-avg_r2), y=avg_r2)) +
  geom_point() +
  scale_y_continuous(breaks = seq(0.50,1,by=0.05)) +
  theme_classic() +
  ggtitle("Adjusted R2 scores based on counties") +
  ylab("Adjusted R squared") +
  theme(
    panel.grid.major.y = element_line(size = 0.4, linetype = 'solid',colour = "white"),
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(angle = 45, vjust = 1,hjust = 1,size = 7),
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.title.x = element_blank(),
    legend.title = element_blank()
  )







